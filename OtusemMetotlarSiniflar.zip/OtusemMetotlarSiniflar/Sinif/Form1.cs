namespace Sinif
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Ogrenci ogrenci1 = new Ogrenci();  //instance
            ogrenci1.Ad = "Ali";
            ogrenci1.Soyad = "�al���r";
            ogrenci1.Yas = 22;
            ogrenci1.Calis();

            Ogrenci ogrenci3 = new Ogrenci()
            {
                Yas = 33,
                Soyad = "Demir",
                Ad = "Salih",
            };



            Ogrenci ogrenci2 = new Ogrenci();
            ogrenci2.Ad = "Ceren";
            ogrenci2.Soyad = "D�ndar";
            ogrenci2.Yas = 25;
            ogrenci2.Calis();
        }
    }
}
