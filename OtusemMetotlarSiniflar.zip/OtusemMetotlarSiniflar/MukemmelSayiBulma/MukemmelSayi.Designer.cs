﻿namespace MukemmelSayiBulma
{
    partial class MukemmelSayi
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnBul = new Button();
            label2 = new Label();
            label1 = new Label();
            txtSayi2 = new TextBox();
            txtSayi1 = new TextBox();
            lblSonuc = new Label();
            SuspendLayout();
            // 
            // btnBul
            // 
            btnBul.Location = new Point(83, 102);
            btnBul.Name = "btnBul";
            btnBul.Size = new Size(389, 55);
            btnBul.TabIndex = 9;
            btnBul.Text = "BUL";
            btnBul.UseVisualStyleBackColor = true;
            btnBul.Click += btnBul_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(287, 46);
            label2.Name = "label2";
            label2.Size = new Size(44, 20);
            label2.TabIndex = 8;
            label2.Text = "Sayı2";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(83, 42);
            label1.Name = "label1";
            label1.Size = new Size(44, 20);
            label1.TabIndex = 7;
            label1.Text = "Sayı1";
            // 
            // txtSayi2
            // 
            txtSayi2.Location = new Point(347, 42);
            txtSayi2.Name = "txtSayi2";
            txtSayi2.Size = new Size(125, 27);
            txtSayi2.TabIndex = 6;
            // 
            // txtSayi1
            // 
            txtSayi1.Location = new Point(139, 42);
            txtSayi1.Name = "txtSayi1";
            txtSayi1.Size = new Size(125, 27);
            txtSayi1.TabIndex = 5;
            // 
            // lblSonuc
            // 
            lblSonuc.BorderStyle = BorderStyle.FixedSingle;
            lblSonuc.Location = new Point(83, 189);
            lblSonuc.Name = "lblSonuc";
            lblSonuc.Size = new Size(389, 133);
            lblSonuc.TabIndex = 10;
            // 
            // MukemmelSayi
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(568, 367);
            Controls.Add(lblSonuc);
            Controls.Add(btnBul);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtSayi2);
            Controls.Add(txtSayi1);
            Name = "MukemmelSayi";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnBul;
        private Label label2;
        private Label label1;
        private TextBox txtSayi2;
        private TextBox txtSayi1;
        private Label lblSonuc;
    }
}
