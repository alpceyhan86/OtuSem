namespace MukemmelSayiBulma
{
    public partial class MukemmelSayi : Form
    {
        string MukemmelMi5()
        {

            string sonuc = "";
            int pozitifBolenleriToplami;

            for (int i = Convert.ToInt32(txtSayi1.Text); i <= Convert.ToInt32(txtSayi2.Text); i++)
            {
                pozitifBolenleriToplami = 0;
                //pozitif b�lenleri toplam�n� bul
                for (int j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        pozitifBolenleriToplami += j;
                    }

                }

                if (pozitifBolenleriToplami == i)
                    sonuc += " " + i + " ";

            }
         
            return sonuc;

        }
        void MukemmelSayiMi4()
        {

            string sonuc = "";
            int pozitifBolenleriToplami;

            for (int i = Convert.ToInt32(txtSayi1.Text); i <= Convert.ToInt32(txtSayi2.Text); i++)
            {
                pozitifBolenleriToplami = 0;
                //pozitif b�lenleri toplam�n� bul
                for (int j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        pozitifBolenleriToplami += j;
                    }

                }

                if (pozitifBolenleriToplami == i)
                    sonuc += " " + i + " ";

            }
            MessageBox.Show(sonuc);

            lblSonuc.Text = sonuc;
        }
        string MukemmelMi2(int altLimit, int ustLimit)
        {
            string sonuc = "";
            int pozitifBolenleriToplami;
            for (int i = altLimit; i <= ustLimit; i++)
            {
                pozitifBolenleriToplami = 0;
                //pozitif b�lenleri toplam�n� bul
                for (int j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        pozitifBolenleriToplami += j;
                    }

                }

                if (pozitifBolenleriToplami == i)
                    sonuc += " " + i.ToString() + " ";

            }
            return sonuc;

        }

        void MukemmelMi3(int altLimit, int ustLimit)
        {
            string sonuc = "";
            int pozitifBolenleriToplami;
            for (int i = altLimit; i <= ustLimit; i++)
            {
                pozitifBolenleriToplami = 0;
                //pozitif b�lenleri toplam�n� bul
                for (int j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        pozitifBolenleriToplami += j;
                    }

                }

                if (pozitifBolenleriToplami == i)
                    sonuc += " " + i + " ";

            }
            MessageBox.Show(sonuc);

            lblSonuc.Text = sonuc;

        }
        bool MukemmelMi(int sayi)
        {
            int pozitifBolenleriToplami = 0;


            //pozitif b�lenleri toplam�n� bul
            for (int i = 1; i < sayi; i++)
            {
                if (sayi % i == 0)
                {
                    pozitifBolenleriToplami += i;
                }

            }

            //sonuca g�re return edilecek de�eri ver
            if (pozitifBolenleriToplami == sayi)
                return true;
            else
                return false;


        }
        public MukemmelSayi()
        {
            InitializeComponent();
        }

        private void btnBul_Click(object sender, EventArgs e)
        {

            lblSonuc.Text = "";
            //Bize ne gerekli?
            //M�kemmel say� olup olmad���n� bulan metod
            //O metodu burada �a��raca��z. Neden burada?
            //��nk� butona bas�ld���nda bulunmas�n� istiyoruz.
            //Metodsuz da yapabiliriz ama bulma i�lemini metoda ��kar�rsak, hem okunu�, d�zenlilik a��s�ndan daha rahat olur. Bulma i�lemini ba�ka yerlerde de yapmak istesek direkt metodu �a��rmak yeterli olacakt�r. (Metodsuz olsayd� o kodlar tekrar yaz�lacakt�)
            //Hata olursa ya da g�ncelleme olursa direkt metod d�zeltilir.
            //Metod olmasayd� teker teker tekrar kodlar d�zeltilecekti.



            //1.yol
            //int altLimit = Convert.ToInt32(txtSayi1.Text);
            //int ustLimit = Convert.ToInt32(txtSayi2.Text);

            //for (int i = altLimit; i <= ustLimit; i++)
            //{

            //    if (MukemmelMi(i))
            //        lblSonuc.Text += i + ",";
            //}


            //2.yol
            //lblSonuc.Text= MukemmelMi2(Convert.ToInt32(txtSayi1.Text), Convert.ToInt32(txtSayi2.Text));



            //3.yol
            //  MukemmelMi3(Convert.ToInt32(txtSayi1.Text), Convert.ToInt32(txtSayi2.Text));

            //4.yol
           // MukemmelSayiMi4();


            //5.yol
           // lblSonuc.Text= MukemmelMi5();


        }
    }
}
