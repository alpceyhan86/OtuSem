namespace OtusemMetotlarSiniflar
{

    //1) Parametre alan, de�er d�nd�ren
    //2) Parametre almayan, de�er d�nd�ren
    //3) Parametre almayan, de�er d�nd�rmeyen
    //4) Parametre alan, de�er d�nd�rmeyen

    //Metod tan�m�:
    /*    d�n��_t�r� MetodAd� (parametre/ler)
     *    {
     *       metodun ne yapaca��n� yazaca��z!!!!!
     *    
     *    }
     * 
     * 
     * 
     * */



    public partial class Form1 : Form
    {
      
        //Durum 1:

        int Topla(int a, int b)
        {
            return a + b;
        }

        //Durum 2:

        int PiGetir()
        {
            return 3;
        }


        //Durum 3:

        void Karsila()
        {
            MessageBox.Show("Selam");
        }

        //Durum 4:
        
        void KisiselKarsila(string isim)
        {
            MessageBox.Show("Selam: " + isim);
          
        }



        //�rnek (durum1 i�in):

        int Ornek1(int a, int b,string kelime)
        {
            txtSayi1.Text = kelime;
            return a + b;
        }
        public Form1()
        {

            InitializeComponent();

        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
          

            // durum 1 i�in
            // int sonuc = Topla(Convert.ToInt32(txtSayi1.Text), Convert.ToInt32(txtSayi2.Text));
            //MessageBox.Show(Topla(Convert.ToInt32(txtSayi1.Text), Convert.ToInt32(txtSayi2.Text)).ToString());
            //Topla(Convert.ToInt32(txtSayi1.Text), Convert.ToInt32(txtSayi2.Text));

            //durum2 i�in
            //int sonuc = PiGetir();
            //MessageBox.Show(sonuc.ToString());

            //durum3 i�in
            //var sonuc = Karsila();  //HATA ALIRIZ!!! ��nk� bu metot void
            //MessageBox.Show(Karsila()); //HATA ALIRIZ!!! ��nk� bu metot void
            // int toplam += Karsila(); //HATA ALIRIZ!!! ��nk� bu metot void
            // Karsila();

            //durum4 i�in

            //var sonuc = KisiselKarsila("Sibel"); //HATA ALIRIZ!!! ��nk� bu metot void
            //MessageBox.Show(KisiselKarsila("Sibel")); //HATA ALIRIZ!!! ��nk� bu metot void
            // int toplam += KisiselKarsila("Sibel");  //HATA ALIRIZ!!! ��nk� bu metot void
            //KisiselKarsila("h�seyin");

            //MessageBox.Show(Ornek1(100, 850, "Tufan").ToString());
           

        }
    }
}
